import osmnx as ox

ox.settings.use_cache = True
ox.settings.log_console = True

place = "Johar Town, Lahore, Pakistan"
radius = 3000
output_file = "johar_town_route_map.graphml"

print("Downloading road network from OpenStreetMap...")
G = ox.graph_from_address(place, dist=radius, network_type="drive", simplify=True)
print("Saving graph to local file...")
ox.save_graphml(G, filepath=output_file)
print(f"Done! Map saved as {output_file}")
print(f"Total nodes: {len(G.nodes)}")
print(f"Total edges: {len(G.edges)}")
