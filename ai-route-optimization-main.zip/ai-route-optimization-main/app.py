
import os
import math
import time
import heapq
from collections import deque

import streamlit as st
import osmnx as ox
import folium
import pandas as pd
from streamlit_folium import st_folium

st.set_page_config(page_title="AI Dynamic Route Optimization Agent", page_icon="🧭", layout="wide")

st.markdown("""
<style>
    .block-container {padding-top: 1.5rem; padding-bottom: 2rem; max-width: 1250px;}
    .hero-box {background: linear-gradient(135deg, #0f172a, #1e3a8a, #2563eb); padding: 34px; border-radius: 22px; color: white; margin-bottom: 24px; box-shadow: 0 10px 30px rgba(15, 23, 42, 0.22);}
    .hero-title {font-size: 40px; font-weight: 850; margin-bottom: 8px; letter-spacing: -0.5px;}
    .hero-subtitle {font-size: 17px; color: #dbeafe; line-height: 1.6;}
    .step-note {background-color: #eff6ff; color: #1e3a8a; padding: 12px 16px; border-radius: 12px; border-left: 5px solid #2563eb; margin-bottom: 15px; font-size: 15px;}
    .success-note {background-color: #ecfdf5; color: #065f46; padding: 12px 16px; border-radius: 12px; border-left: 5px solid #10b981; margin-bottom: 15px; font-size: 15px;}
    div[data-testid="stMetric"] {background-color: white; padding: 16px; border-radius: 16px; border: 1px solid #e5e7eb; box-shadow: 0 4px 14px rgba(0,0,0,0.05);}
    .stButton > button {border-radius: 12px; border: none; background-color: #2563eb; color: white; padding: 10px 18px; font-weight: 700; transition: 0.2s ease-in-out;}
    .stButton > button:hover {background-color: #1d4ed8; color: white; transform: translateY(-1px);}
    .stDownloadButton > button {border-radius: 12px; border: none; background-color: #16a34a; color: white; padding: 10px 18px; font-weight: 700;}
    .stDownloadButton > button:hover {background-color: #15803d; color: white;}
    .footer-box {background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 14px; padding: 16px; color: #334155; margin-top: 20px;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero-box">
    <div class="hero-title">AI-Based Dynamic Route Optimization Agent</div>
    <div class="hero-subtitle">A real-world route planning project using OpenStreetMap, BFS, DFS, UCS, A*, admissible heuristic and non-admissible heuristic comparison.</div>
</div>
""", unsafe_allow_html=True)

LOCAL_GRAPH_FILE = "johar_town_route_map.graphml"
DEFAULT_AREA = "Johar Town, Lahore, Pakistan"
DEFAULT_RADIUS = 3000

default_values = {
    "map_loaded": False, "G": None, "nodes": None, "edges": None,
    "start_point": None, "end_point": None, "start_node": None, "end_node": None,
    "route": None, "route_result": None, "comparison_results": None, "recommended_result": None,
}
for key, value in default_values.items():
    if key not in st.session_state:
        st.session_state[key] = value

def reset_route_data():
    st.session_state.start_point = None
    st.session_state.end_point = None
    st.session_state.start_node = None
    st.session_state.end_node = None
    st.session_state.route = None
    st.session_state.route_result = None
    st.session_state.comparison_results = None
    st.session_state.recommended_result = None

def reset_all():
    st.session_state.map_loaded = False
    st.session_state.G = None
    st.session_state.nodes = None
    st.session_state.edges = None
    reset_route_data()

def get_edge_cost(G, current, neighbor):
    edge_data = G.get_edge_data(current, neighbor)
    if edge_data is None:
        return float("inf")
    min_cost = float("inf")
    for _, data in edge_data.items():
        length = data.get("length", 1)
        if length < min_cost:
            min_cost = length
    return min_cost

def calculate_path_cost(G, path):
    if not path:
        return float("inf")
    total_cost = 0
    for i in range(len(path) - 1):
        total_cost += get_edge_cost(G, path[i], path[i + 1])
    return total_cost

def reconstruct_path(parent, start, goal):
    if goal not in parent:
        return []
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent.get(current)
    path.reverse()
    return path

def haversine_distance(G, node1, node2):
    lat1 = math.radians(G.nodes[node1]["y"])
    lon1 = math.radians(G.nodes[node1]["x"])
    lat2 = math.radians(G.nodes[node2]["y"])
    lon2 = math.radians(G.nodes[node2]["x"])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return 6371000 * c

def route_to_coordinates(G, route):
    route_coords = []
    for i in range(len(route) - 1):
        u, v = route[i], route[i + 1]
        edge_data = G.get_edge_data(u, v)
        if edge_data:
            best_edge = min(edge_data.values(), key=lambda data: data.get("length", float("inf")))
            if "geometry" in best_edge:
                coords = [(lat, lon) for lon, lat in best_edge["geometry"].coords]
                route_coords.extend(coords)
            else:
                route_coords.append((G.nodes[u]["y"], G.nodes[u]["x"]))
                route_coords.append((G.nodes[v]["y"], G.nodes[v]["x"]))
    return route_coords

def load_graph_from_online(area, radius):
    ox.settings.use_cache = True
    ox.settings.log_console = False
    return ox.graph_from_address(area, dist=radius, network_type="drive", simplify=True)

def choose_recommended_algorithm(results):
    if not results:
        return None
    ucs = next((r for r in results if r["algorithm"] == "UCS"), None)
    astar_adm = next((r for r in results if r["algorithm"] == "A* Admissible Heuristic"), None)
    if ucs and astar_adm and abs(ucs["cost"] - astar_adm["cost"]) < 1:
        return astar_adm
    return min(results, key=lambda r: (r["cost"], r["nodes_explored"], r["time_taken"]))

def bfs_search(G, start, goal):
    start_time = time.time()
    queue = deque([start])
    visited = {start}
    parent = {start: None}
    explored_nodes = 0
    while queue:
        current = queue.popleft()
        explored_nodes += 1
        if current == goal:
            path = reconstruct_path(parent, start, goal)
            return {"algorithm": "BFS", "path": path, "cost": calculate_path_cost(G, path), "nodes_explored": explored_nodes, "time_taken": time.time() - start_time}
        for neighbor in G.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                parent[neighbor] = current
                queue.append(neighbor)
    return None

def dfs_search(G, start, goal):
    start_time = time.time()
    stack = [start]
    visited = set()
    parent = {start: None}
    explored_nodes = 0
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        explored_nodes += 1
        if current == goal:
            path = reconstruct_path(parent, start, goal)
            return {"algorithm": "DFS", "path": path, "cost": calculate_path_cost(G, path), "nodes_explored": explored_nodes, "time_taken": time.time() - start_time}
        for neighbor in G.neighbors(current):
            if neighbor not in visited:
                if neighbor not in parent:
                    parent[neighbor] = current
                stack.append(neighbor)
    return None

def ucs_search(G, start, goal):
    start_time = time.time()
    priority_queue = [(0, start)]
    parent = {start: None}
    cost_so_far = {start: 0}
    visited = set()
    explored_nodes = 0
    while priority_queue:
        current_cost, current = heapq.heappop(priority_queue)
        if current in visited:
            continue
        visited.add(current)
        explored_nodes += 1
        if current == goal:
            path = reconstruct_path(parent, start, goal)
            return {"algorithm": "UCS", "path": path, "cost": current_cost, "nodes_explored": explored_nodes, "time_taken": time.time() - start_time}
        for neighbor in G.neighbors(current):
            edge_cost = get_edge_cost(G, current, neighbor)
            new_cost = current_cost + edge_cost
            if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                cost_so_far[neighbor] = new_cost
                parent[neighbor] = current
                heapq.heappush(priority_queue, (new_cost, neighbor))
    return None

def astar_search(G, start, goal, heuristic_type="admissible"):
    start_time = time.time()
    priority_queue = [(0, 0, start)]
    parent = {start: None}
    cost_so_far = {start: 0}
    visited = set()
    explored_nodes = 0
    while priority_queue:
        _, current_cost, current = heapq.heappop(priority_queue)
        if current in visited:
            continue
        visited.add(current)
        explored_nodes += 1
        if current == goal:
            path = reconstruct_path(parent, start, goal)
            algo_name = "A* Admissible Heuristic" if heuristic_type == "admissible" else "A* Non-Admissible Heuristic"
            return {"algorithm": algo_name, "path": path, "cost": current_cost, "nodes_explored": explored_nodes, "time_taken": time.time() - start_time}
        for neighbor in G.neighbors(current):
            edge_cost = get_edge_cost(G, current, neighbor)
            new_cost = current_cost + edge_cost
            if neighbor not in cost_so_far or new_cost < cost_so_far[neighbor]:
                cost_so_far[neighbor] = new_cost
                parent[neighbor] = current
                h = haversine_distance(G, neighbor, goal)
                if heuristic_type == "non_admissible":
                    h = h * 2.5
                heapq.heappush(priority_queue, (new_cost + h, new_cost, neighbor))
    return None

def run_selected_algorithm(G, start_node, end_node, algorithm):
    if algorithm == "BFS": return bfs_search(G, start_node, end_node)
    if algorithm == "DFS": return dfs_search(G, start_node, end_node)
    if algorithm == "UCS": return ucs_search(G, start_node, end_node)
    if algorithm == "A* Admissible Heuristic": return astar_search(G, start_node, end_node, "admissible")
    if algorithm == "A* Non-Admissible Heuristic": return astar_search(G, start_node, end_node, "non_admissible")
    return None

st.sidebar.markdown("## Navigation Settings")
st.sidebar.markdown("Customize route display and demo speed.")
show_full_network = st.sidebar.checkbox("Show full road network lines", value=False, help="Keep OFF for fast and clean demo.")
route_color = st.sidebar.selectbox("Route color", ["red", "yellow", "green", "purple", "orange"], index=0)
st.sidebar.markdown("---")
st.sidebar.success("Recommended: Keep road network OFF and route color RED for demo.")

st.markdown("### Step 1: Load Real Map")
st.markdown('<div class="step-note">Use saved local map for faster demo. Use download option only for first-time setup.</div>', unsafe_allow_html=True)
load_mode = st.radio("Map Loading Mode:", ["Load saved local map file", "Download map from OpenStreetMap"], horizontal=True)
area = st.text_input("Area name:", DEFAULT_AREA)
radius = st.slider("Radius in meters:", min_value=500, max_value=4000, value=DEFAULT_RADIUS, step=100)
col1, col2, col3 = st.columns([1, 1, 1])
with col1: load_map_btn = st.button("Load Map")
with col2: download_save_btn = st.button("Download and Save Map")
with col3: reset_btn = st.button("Reset")

if reset_btn:
    reset_all()
    st.success("Project reset successfully!")

if download_save_btn:
    try:
        with st.spinner("Downloading road network and saving local map file..."):
            G = load_graph_from_online(area, radius)
            ox.save_graphml(G, filepath=LOCAL_GRAPH_FILE)
        st.success(f"Map saved locally as: {LOCAL_GRAPH_FILE}")
        st.info("Next time select 'Load saved local map file' for faster loading.")
    except Exception as e:
        st.error("Map download/save failed.")
        st.exception(e)

if load_map_btn:
    try:
        with st.spinner("Loading map..."):
            if load_mode == "Load saved local map file":
                if not os.path.exists(LOCAL_GRAPH_FILE):
                    st.warning(f"Local file '{LOCAL_GRAPH_FILE}' not found. Click 'Download and Save Map' first.")
                    st.stop()
                G = ox.load_graphml(LOCAL_GRAPH_FILE)
            else:
                G = load_graph_from_online(area, radius)
            nodes, edges = ox.graph_to_gdfs(G)
            st.session_state.G = G
            st.session_state.nodes = nodes
            st.session_state.edges = edges
            st.session_state.map_loaded = True
            reset_route_data()
        st.success("Map loaded successfully!")
    except Exception as e:
        st.error("Map load nahi hua. Error neeche hai:")
        st.exception(e)

if st.session_state.map_loaded:
    st.markdown("### Step 2: Select Start and Destination")
    st.markdown('<div class="step-note">Enter real-world locations. The system will find nearest road nodes automatically.</div>', unsafe_allow_html=True)
    start_location = st.text_input("Start location:", "University of Management and Technology, Lahore, Pakistan")
    end_location = st.text_input("Destination location:", "Emporium Mall, Lahore, Pakistan")
    if st.button("Set Start and Destination"):
        try:
            with st.spinner("Finding nearest road nodes for start and destination..."):
                start_lat, start_lon = ox.geocode(start_location)
                end_lat, end_lon = ox.geocode(end_location)
                G = st.session_state.G
                start_node = ox.distance.nearest_nodes(G, start_lon, start_lat)
                end_node = ox.distance.nearest_nodes(G, end_lon, end_lat)
                st.session_state.start_point = (start_lat, start_lon)
                st.session_state.end_point = (end_lat, end_lon)
                st.session_state.start_node = start_node
                st.session_state.end_node = end_node
                st.session_state.route = None
                st.session_state.route_result = None
                st.session_state.comparison_results = None
                st.session_state.recommended_result = None
            st.success("Start and destination selected successfully!")
        except Exception as e:
            st.error("Start/Destination find nahi ho saki.")
            st.exception(e)

if st.session_state.map_loaded:
    st.markdown("### Step 3: Find Route using AI Search Algorithm")
    st.markdown('<div class="step-note">Run BFS, DFS, UCS, A* or compare all algorithms in one click.</div>', unsafe_allow_html=True)
    algorithm = st.selectbox("Choose Algorithm:", ["BFS", "DFS", "UCS", "A* Admissible Heuristic", "A* Non-Admissible Heuristic", "Compare All"])
    if st.button("Find Route"):
        if st.session_state.start_node is None or st.session_state.end_node is None:
            st.warning("Pehle Start aur Destination set karo.")
        else:
            try:
                G = st.session_state.G
                start_node = st.session_state.start_node
                end_node = st.session_state.end_node
                if algorithm == "Compare All":
                    results = []
                    for algo in ["BFS", "DFS", "UCS", "A* Admissible Heuristic", "A* Non-Admissible Heuristic"]:
                        result = run_selected_algorithm(G, start_node, end_node, algo)
                        if result is not None:
                            results.append(result)
                    st.session_state.comparison_results = results
                    st.session_state.recommended_result = choose_recommended_algorithm(results)
                    if st.session_state.recommended_result is not None:
                        st.session_state.route = st.session_state.recommended_result["path"]
                        st.session_state.route_result = st.session_state.recommended_result
                    st.success("All algorithms compared successfully!")
                else:
                    result = run_selected_algorithm(G, start_node, end_node, algorithm)
                    if result is None:
                        st.error("Route not found.")
                    else:
                        st.session_state.route = result["path"]
                        st.session_state.route_result = result
                        st.session_state.comparison_results = None
                        st.session_state.recommended_result = result
                        st.success("Route found successfully!")
            except Exception as e:
                st.error("Route find nahi hua.")
                st.exception(e)

if st.session_state.map_loaded:
    st.markdown("### Real Map Visualization")
    nodes = st.session_state.nodes
    edges = st.session_state.edges
    col_a, col_b = st.columns(2)
    col_a.metric("Total Nodes", len(nodes))
    col_b.metric("Total Roads / Edges", len(edges))
    center_lat = nodes.geometry.y.mean()
    center_lon = nodes.geometry.x.mean()
    m = folium.Map(location=[center_lat, center_lon], zoom_start=14, tiles="OpenStreetMap")
    if show_full_network:
        for _, row in edges.iterrows():
            if row.geometry is not None:
                coords = [(lat, lon) for lon, lat in row.geometry.coords]
                folium.PolyLine(coords, weight=1, color="blue", opacity=0.55).add_to(m)
    if st.session_state.start_point is not None:
        folium.Marker(location=st.session_state.start_point, popup="Start Location", tooltip="Start", icon=folium.Icon(color="green", icon="play")).add_to(m)
    if st.session_state.end_point is not None:
        folium.Marker(location=st.session_state.end_point, popup="Destination Location", tooltip="Destination", icon=folium.Icon(color="red", icon="flag")).add_to(m)
    if st.session_state.route is not None:
        route_coords = route_to_coordinates(st.session_state.G, st.session_state.route)
        folium.PolyLine(route_coords, weight=7, color=route_color, opacity=1.0, tooltip="AI Suggested Route").add_to(m)
    st_folium(m, width=1150, height=650, key="real_map")

if st.session_state.route_result is not None:
    result = st.session_state.route_result
    st.markdown("### Route Result")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Algorithm", result["algorithm"])
    col2.metric("Cost / Distance", f"{result['cost']:.2f} m")
    col3.metric("Nodes Explored", result["nodes_explored"])
    col4.metric("Time Taken", f"{result['time_taken']:.6f} sec")
    if st.session_state.recommended_result is not None:
        st.markdown(f'<div class="success-note"><b>Recommended:</b> {st.session_state.recommended_result["algorithm"]} is selected because it gives a strong balance between route cost and search efficiency.</div>', unsafe_allow_html=True)
    with st.expander("Show Route Node IDs"):
        st.code(result["path"])

if st.session_state.comparison_results is not None:
    st.markdown("### Algorithm Comparison Dashboard")
    table_data = []
    for result in st.session_state.comparison_results:
        table_data.append({
            "Algorithm": result["algorithm"],
            "Total Cost / Distance (meters)": round(result["cost"], 2),
            "Nodes in Path": len(result["path"]),
            "Nodes Explored": result["nodes_explored"],
            "Time Taken (seconds)": round(result["time_taken"], 6),
            "Explanation": (
                "Level-by-level search, ignores road cost" if result["algorithm"] == "BFS"
                else "Deep search, route can be long and non-optimal" if result["algorithm"] == "DFS"
                else "Finds lowest-cost path using road length" if result["algorithm"] == "UCS"
                else "Uses safe straight-line distance heuristic" if result["algorithm"] == "A* Admissible Heuristic"
                else "Overestimates heuristic; may be faster but not always optimal"
            )
        })
    df = pd.DataFrame(table_data)
    st.dataframe(df, use_container_width=True)
    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button(label="Download Comparison Results as CSV", data=csv, file_name="algorithm_comparison_results.csv", mime="text/csv")
    st.info("BFS and DFS are included for comparison. For real route optimization, UCS and A* are more suitable because they use road distance/cost.")

with st.expander("Project Explanation"):
    st.write("""
    This project uses real road data from OpenStreetMap. The road network is converted into a graph.

    - Intersections and road points are treated as nodes.
    - Roads are treated as edges.
    - Road length in meters is used as path cost.
    - BFS and DFS are uninformed search algorithms.
    - UCS finds the lowest-cost path using road length.
    - A* uses f(n) = g(n) + h(n).
    - g(n) is the actual road cost from start to current node.
    - h(n) is the estimated straight-line distance from current node to goal.
    - Non-admissible A* multiplies the heuristic by 2.5, so it may explore fewer nodes but can miss the optimal path.
    """)

if not st.session_state.map_loaded:
    st.info("Load a saved local map file or download a map from OpenStreetMap to start.")

st.markdown("""
<div class="footer-box">
    <b>Project:</b> AI-Based Dynamic Route Optimization Agent<br>
    <b>Tools:</b> Python, Streamlit, OpenStreetMap, OSMnx, Folium<br>
    <b>Algorithms:</b> BFS, DFS, UCS, A* Admissible, A* Non-Admissible
</div>
""", unsafe_allow_html=True)
