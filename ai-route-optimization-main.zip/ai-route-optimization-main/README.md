# AI-Based Dynamic Route Optimization Agent - Modern UI Version

## Included
- Modern Streamlit UI
- Real map data using OpenStreetMap
- Local GraphML map load support
- BFS, DFS, UCS, A* admissible and A* non-admissible heuristic
- Route drawing on real map
- Algorithm comparison dashboard
- Best algorithm recommendation
- Download comparison results as CSV

## Run
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python download_map.py
streamlit run app.py
```

If streamlit command does not work:
```powershell
python -m streamlit run app.py
```
